const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User ' },
    bookId: { type: mongoose.Schema.Types.ObjectId, ref: 'Book' },
    issueDate: { type: Date, default: Date.now },
    returnDate: { type: Date },
    fine: { type: Number, default: 0 },
});

module.exports = mongoose.model('Transaction', transactionSchema);