const express = require('express');
const Book = require('../models/Book');
const Transaction = require('../models/Transaction');
const router = express.Router();

// Middleware to check if user is logged in
function isUser (req, res, next) {
    if (req.session.userId) {
        return next();
    }
    res.redirect('/auth/login');
}

// User Dashboard
router.get('/dashboard', isUser , async (req, res) => {
    const books = await Book.find({ available: true });
    res.render('user/dashboard', { books });
});

// Issue Book
router.post('/issue-book', isUser , async (req, res) => {
    const { bookId } = req.body;
    const book = await Book.findById(bookId);

    if (book && book.available) {
        const transaction = new Transaction({
            userId: req.session.userId,
            bookId: book._id,
            issueDate: new Date(),
            returnDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // 15 days later
        });
        await transaction.save();
        book.available = false; // Mark the book as not available
        await book.save();
        res.redirect('/user/dashboard');
    } else {
        res.render('user/dashboard', { error: 'Book not found or already issued' });
    }
});

// Return Book
router.get('/return-book', isUser , async (req, res) => {
    const transactions = await Transaction.find({ userId: req.session.userId }).populate('bookId');
    res.render('user/return-book', { transactions });
});

router.post('/return-book', isUser , async (req, res) => {
    const { transactionId, returnDate } = req.body;
    const transaction = await Transaction.findById(transactionId);

    if (transaction) {
        const book = await Book.findById(transaction.bookId);
        book.available = true; // Mark the book as available
        await book.save();
        await Transaction.deleteOne({ _id: transactionId });
        res.redirect('/user/dashboard');
    } else {
        res.render('user/return-book', { error: 'Transaction not found' });
    }
});

// Membership Management
router.get('/membership', isUser , (req, res) => {
    res.render('user/membership');
});

// Add Membership
router.post('/add-membership', isUser , async (req, res) => {
    const { membershipType } = req.body; // 6 months, 1 year, or 2 years
    // Logic to add membership (e.g., save to database)
    // For simplicity, we can just redirect to the dashboard
    res.redirect('/user/dashboard');
});

// Update Membership
router.post('/update-membership', isUser , async (req, res) => {
    const { membershipNumber, action } = req.body; // action could be 'extend' or 'cancel'
    // Logic to update membership based on the action
    // For simplicity, we can just redirect to the dashboard
    res.redirect('/user/dashboard');
});

module.exports = router;