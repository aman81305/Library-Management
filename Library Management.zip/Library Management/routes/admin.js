const express = require('express');
const Book = require('../models/Book');
const User = require('../models/User');
const router = express.Router();

// Middleware to check if user is admin
function isAdmin(req, res, next) {
    if (req.session.role === 'admin') {
        return next();
    }
    res.redirect('/auth/login');
}

// Admin Dashboard
router.get('/dashboard', isAdmin, (req, res) => {
    res.render('admin/dashboard');
});

// Add Book
router.get('/add-book', isAdmin, (req, res) => {
    res.render('admin/add-book');
});

router.post('/add-book', isAdmin, async (req, res) => {
    const { title, author, serialNo } = req.body;
    const newBook = new Book({ title, author, serialNo });
    await newBook.save();
    res.redirect('/admin/dashboard');
});

// Update Book
router.get('/update-book/:id', isAdmin, async (req, res) => {
    const book = await Book.findById(req.params.id);
    res.render('admin/update-book', { book });
});

router.post('/update-book/:id', isAdmin, async (req, res) => {
    const { title, author, serialNo } = req.body;
    await Book.findByIdAndUpdate(req.params.id, { title, author, serialNo });
    res.redirect('/admin/dashboard');
});

// User Management
router.get('/users', isAdmin, async (req, res) => {
    const users = await User.find();
    res.render('admin/users', { users });
});

// Add User
router.get('/add-user', isAdmin, (req, res) => {
    res.render('admin/add-user');
});

router.post('/add-user', isAdmin, async (req, res) => {
    const { username, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser  = new User({ username, password: hashedPassword, role });
    await newUser .save();
    res.redirect('/admin/users');
});

module.exports = router;