const express = require('express');
const User = require('../models/User');
const bcrypt = require('bcrypt');
const router = express.Router();

// Render Login Page
router.get('/login', (req, res) => {
    res.render('auth/login', { error: null });
});

// Login Route
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    if (user && await bcrypt.compare(password, user.password)) {
        req.session.userId = user._id;
        req.session.role = user.role;
        res.redirect(user.role === 'admin' ? '/admin/dashboard' : '/user/dashboard');
    } else {
        res.render('auth/login', { error: 'Invalid credentials' });
    }
});

// Logout Route
router.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/user/dashboard');
        }
        res.redirect('/auth/login');
    });
});

module.exports = router;